﻿ /*  作者：       tianzh
 *  创建时间：   2012/8/4 21:46:01
 *
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TZHSWEET.UI
{
    /// <summary>
    /// 匿名访问标记
    /// </summary>
     [AttributeUsage(AttributeTargets.Method)]
   public class AnonymousAttribute:Attribute
    {
    }
}
