﻿ /*  作者：       tianzh
 *  创建时间：   2012/8/5 19:04:21
 *
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TZHSWEET.UI
{
    /// <summary>
    /// UI异常返回
    /// </summary>
      [AttributeUsage(AttributeTargets.Method)]
   public  class LigerUIExceptionResultAttribute:Attribute
    {
         
    }
}
