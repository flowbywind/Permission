﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TZHSWEET.Entity;
using TZHSWEET.IDao;
namespace TZHSWEET.EFDao
{
    public class PermissionEFDao : BaseEFDao<tbPermission>, IPermissionDao<tbPermission>
    {

    }
}
