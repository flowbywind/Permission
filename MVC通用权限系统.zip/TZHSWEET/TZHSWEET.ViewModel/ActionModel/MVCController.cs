﻿ /*  作者：       tianzh
 *  创建时间：   2012/7/25 10:32:21
 *
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TZHSWEET.ViewModel
{
    /// <summary>
    /// 控制器
    /// </summary>
  public  class MVCController
    {
        /// <summary>
        /// 控制器
        /// </summary>
        public string ControllerName { get; set; }
        /// <summary>
        /// 描述
        /// </summary>
        public string Description { get; set; }
        /// <summary>
        /// 链接地址
        /// </summary>
        public string LinkUrl { get; set; }
    }
}
