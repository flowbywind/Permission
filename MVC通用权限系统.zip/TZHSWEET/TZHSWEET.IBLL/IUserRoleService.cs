﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TZHSWEET.Entity;

namespace TZHSWEET.IBLL
{
   public interface IUserRoleService : IBaseService<tbUserRole>
    {
      
    }
}
